package com.example.appbuilder

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.Base64
import java.util.zip.ZipInputStream

/** Minimal GitHub REST client (no third-party deps). */
class GitHubApi(private val token: String, owner: String, repo: String) {
    private val base = "https://api.github.com/repos/$owner/$repo"

    private fun conn(url: String, method: String = "GET"): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = false
        }

    private fun fail(c: HttpURLConnection): Nothing =
        throw IllegalStateException("GitHub ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()?.take(300)}")

    private fun getJson(url: String): JSONObject {
        val c = conn(url)
        if (c.responseCode !in 200..299) fail(c)
        return JSONObject(c.inputStream.bufferedReader().readText())
    }

    class Workflow(val id: Long, val name: String, val path: String)

    fun defaultBranch(): String = getJson(base).getString("default_branch")

    fun workflows(): List<Workflow> {
        val arr = getJson("$base/actions/workflows?per_page=50").getJSONArray("workflows")
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.getString("state") == "active" }
            .map { Workflow(it.getLong("id"), it.getString("name"), it.getString("path")) }
    }

    /** true = run queued; false = workflow has no workflow_dispatch trigger (404/422). */
    fun tryDispatch(workflowId: String, ref: String): Boolean {
        val c = conn("$base/actions/workflows/$workflowId/dispatches", "POST")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("ref", ref).toString().toByteArray()) }
        return when (c.responseCode) {
            204 -> true
            404, 422 -> false
            else -> fail(c)
        }
    }

    private fun enc(path: String) = path.split("/").joinToString("/") {
        java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
    }

    /** Name of the first .zip in the repo root, or null. */
    fun findRootZip(branch: String): String? {
        val c = conn("$base/contents?ref=$branch")
        if (c.responseCode != 200) return null
        val arr = org.json.JSONArray(c.inputStream.bufferedReader().readText())
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            if (f.getString("type") == "file" && f.getString("name").endsWith(".zip", true)) return f.getString("name")
        }
        return null
    }

    private fun existingSha(path: String, branch: String): String? {
        val c = conn("$base/contents/${enc(path)}?ref=$branch")
        if (c.responseCode != 200) return null
        return JSONObject(c.inputStream.bufferedReader().readText()).optString("sha").ifEmpty { null }
    }

    /** Creates the file, or replaces it if it already exists. */
    fun putFile(path: String, bytes: ByteArray, branch: String, message: String) {
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.getEncoder().encodeToString(bytes))
            .put("branch", branch)
        existingSha(path, branch)?.let { body.put("sha", it) }
        val data = body.toString().toByteArray()
        val c = conn("$base/contents/${enc(path)}", "PUT")
        c.readTimeout = 180_000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setFixedLengthStreamingMode(data.size)
        c.outputStream.use { it.write(data) }
        if (c.responseCode !in listOf(200, 201)) fail(c)
    }

    /** Finds the run created at/after [since]. */
    fun findRunSince(workflow: String, since: Instant): Long? {
        val runs = getJson("$base/actions/workflows/$workflow/runs?event=workflow_dispatch&per_page=5")
            .getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (!Instant.parse(r.getString("created_at")).isBefore(since)) return r.getLong("id")
        }
        return null
    }

    /** Returns (status, conclusion). conclusion is null until completed. */
    fun runState(runId: Long): Pair<String, String?> {
        val r = getJson("$base/actions/runs/$runId")
        return r.getString("status") to (if (r.isNull("conclusion")) null else r.getString("conclusion"))
    }

    fun firstArtifactId(runId: Long): Long? {
        val arr = getJson("$base/actions/runs/$runId/artifacts").getJSONArray("artifacts")
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (!a.getBoolean("expired")) return a.getLong("id")
        }
        return null
    }

    /** Downloads the artifact zip and extracts the first .apk into [outDir]. */
    fun downloadApk(artifactId: Long, outDir: File): File {
        outDir.mkdirs()
        val c = conn("$base/actions/artifacts/$artifactId/zip")
        val stream = when (c.responseCode) {
            302 -> {
                // Signed storage URL: must NOT receive the GitHub token.
                val loc = c.getHeaderField("Location") ?: error("Missing redirect")
                (URL(loc).openConnection() as HttpURLConnection).apply { readTimeout = 120_000 }.inputStream
            }
            200 -> c.inputStream
            else -> fail(c)
        }
        ZipInputStream(stream).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory && e.name.endsWith(".apk")) {
                    val out = File(outDir, "build.apk")
                    out.outputStream().use { zip.copyTo(it) }
                    return out
                }
            }
        }
        error("No .apk found in artifact")
    }
}
