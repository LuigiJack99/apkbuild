package com.example.appbuilder

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Instant

class MainActivity : ComponentActivity() {

    private val logLines = mutableStateListOf<String>()
    private var busy by mutableStateOf(false)
    private var apk by mutableStateOf<File?>(null)
    private var zipUri by mutableStateOf<Uri?>(null)
    private var zipName by mutableStateOf("")
    private val pickZip =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                zipUri = uri
                zipName = contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) c.getString(i) else null
                } ?: "selected.zip"
            }
        }
    private var builtLabel = ""
    private var builtPkg = ""
    private val queue = ArrayDeque<String>()

    // Each system "Uninstall?" dialog returns here, then we continue to the next one / install.
    private val uninstallLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { nextUninstall() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        setContent {
            MaterialTheme {
                var repoInput by remember { mutableStateOf(prefs.getString("repo", "") ?: "") }
                var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }

                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("GitHub App Builder", style = MaterialTheme.typography.headlineSmall)
                    Field("Repo (owner/name or URL) — saved", repoInput) { repoInput = it }
                    Field("GitHub token — saved", token, secret = true) { token = it }

                    OutlinedButton(
                        enabled = !busy,
                        onClick = { pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (zipUri == null) "Choose project .zip" else "Zip: $zipName (tap to change)") }

                    Button(
                        enabled = !busy && parseRepo(repoInput) != null && token.isNotBlank(),
                        onClick = {
                            prefs.edit().putString("repo", repoInput.trim())
                                .putString("token", token.trim()).apply()
                            startBuild(token.trim(), parseRepo(repoInput)!!)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Working…" else if (zipUri != null) "Upload zip & build" else "Build existing repo") }

                    OutlinedButton(
                        enabled = !busy && apk != null,
                        onClick = { prepareInstall() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Retry install of last build") }

                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    logLines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }

    @Composable
    private fun Field(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
        OutlinedTextField(
            value = value, onValueChange = onChange, label = { Text(label) },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
        )
    }

    private fun log(s: String) { logLines.add(s) }

    /** Accepts "owner/repo", "https://github.com/owner/repo(.git)", etc. */
    private fun parseRepo(input: String): Pair<String, String>? {
        val cleaned = input.trim()
            .removePrefix("https://").removePrefix("http://").removePrefix("github.com/")
            .removeSuffix("/").removeSuffix(".git")
        val parts = cleaned.split("/")
        return if (parts.size >= 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) parts[0] to parts[1] else null
    }

    // ---------- Build via GitHub Actions (everything auto-detected) ----------
    private fun startBuild(token: String, repoId: Pair<String, String>) {
        logLines.clear(); busy = true
        val uri = zipUri
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val api = GitHubApi(token, repoId.first, repoId.second)
                    val branch = api.defaultBranch()
                    log("Repo ${repoId.first}/${repoId.second}, branch $branch")

                    // 0) Replace the zip in the repo with the one picked on the phone
                    if (uri != null) {
                        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Can't read the zip")
                        if (bytes.size < 4 || bytes[0] != 'P'.code.toByte() || bytes[1] != 'K'.code.toByte()) error("That isn't a .zip file")
                        if (bytes.size > 90 * 1024 * 1024) error("Zip is over GitHub's ~100 MB file limit")
                        val zipPath = api.findRootZip(branch) ?: "project.zip"
                        log("Uploading ${bytes.size / 1024} KB to $zipPath…")
                        api.putFile(zipPath, bytes, branch, "Update project zip via app [skip ci]")
                        log("Zip replaced in repo.")
                    }
                    val since = Instant.now().minusSeconds(15) // tolerate clock skew

                    // 1) Try existing workflows (build-looking ones first)
                    val existing = api.workflows().sortedByDescending {
                        val s = (it.name + it.path).lowercase()
                        (if ("apk" in s) 2 else 0) + (if ("build" in s) 1 else 0)
                    }
                    var wfId = existing.firstOrNull { api.tryDispatch(it.id.toString(), branch) }?.id

                    // 2) None dispatchable → add our workflow to the repo, then dispatch it
                    if (wfId == null) {
                        log("No dispatchable workflow. Adding ${WorkflowTemplate.PATH}…")
                        api.putFile(WorkflowTemplate.PATH, WorkflowTemplate.YAML.toByteArray(), branch, "Add APK build workflow [skip ci]")
                        repeat(12) {
                            if (wfId == null) {
                                delay(4000)
                                val w = api.workflows().firstOrNull { it.path == WorkflowTemplate.PATH }
                                if (w != null && api.tryDispatch(w.id.toString(), branch)) wfId = w.id
                            }
                        }
                    }
                    val wf = wfId?.toString() ?: error("Could not start a workflow (token needs repo + workflow scope)")
                    log("Build dispatched.")

                    var runId: Long? = null
                    repeat(20) { if (runId == null) { delay(3000); runId = api.findRunSince(wf, since) } }
                    val id = runId ?: error("Run did not start")
                    log("Run #$id building…")

                    while (true) {
                        delay(6000)
                        val (status, conclusion) = api.runState(id)
                        if (status == "completed") {
                            if (conclusion != "success") error("Build finished: $conclusion (see Actions logs)")
                            break
                        }
                    }
                    log("Downloading APK…")
                    val art = api.firstArtifactId(id) ?: error("No artifact produced")
                    api.downloadApk(art, File(cacheDir, "apks"))
                }
                apk = file
                if (uri != null) { zipUri = null; zipName = "" }
                readApkIdentity(file)
                log("Built \"$builtLabel\" ($builtPkg).")
                prepareInstall()
            } catch (e: Exception) {
                log("Error: ${e.message}")
            } finally { busy = false }
        }
    }

    /** Reads app name + package straight from the built APK, so no name needs to be typed. */
    private fun readApkIdentity(file: File) {
        val pm = packageManager
        val info = pm.getPackageArchiveInfo(file.path, 0)
        val ai = info?.applicationInfo
        if (info == null || ai == null) { builtLabel = ""; builtPkg = ""; return }
        ai.sourceDir = file.path
        ai.publicSourceDir = file.path
        builtPkg = info.packageName
        builtLabel = pm.getApplicationLabel(ai).toString()
    }

    // ---------- Remove same-name apps, then install ----------
    private fun findMatches(): List<ApplicationInfo> {
        val pm = packageManager
        return pm.getInstalledApplications(0).filter {
            it.packageName != packageName &&                      // never remove ourselves
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && // never touch system apps
                (it.packageName == builtPkg ||
                    (builtLabel.isNotEmpty() && pm.getApplicationLabel(it).toString().equals(builtLabel, true)))
        }
    }

    private fun prepareInstall() {
        val matches = findMatches()
        if (matches.isEmpty()) { log("No existing app named \"$builtLabel\"."); installApk(); return }
        queue.clear(); queue.addAll(matches.map { it.packageName })
        log("Removing: " + matches.joinToString { "${packageManager.getApplicationLabel(it)} (${it.packageName})" })
        nextUninstall()
    }

    private fun nextUninstall() {
        val pkg = queue.removeFirstOrNull()
        if (pkg == null) { if (apk != null) installApk(); return }
        uninstallLauncher.launch(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).putExtra(Intent.EXTRA_RETURN_RESULT, true)
        )
    }

    private fun installApk() {
        val file = apk ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            log("Allow \"Install unknown apps\" for this app, come back, tap Retry.")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        log("Installer opened.")
    }
}
