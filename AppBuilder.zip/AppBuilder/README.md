# GitHub App Builder (Android)

Enter your repo once. Pick a project `.zip` on your phone, tap **Upload zip & build**: the app replaces the zip in the repo, builds it on GitHub, and installs the APK.

## Setup (once)
1. Build/install this app (Android Studio, or run `.github/workflows/android-build.yml` on GitHub).
2. Create a GitHub token with `repo` and `workflow` scopes (classic), or fine-grained with
   Actions: read/write, Contents: read/write, Workflows: read/write.
3. Open the app, enter `owner/repo` (or the URL) and the token. Both are saved.

## Zip upload
- Replaces the first `.zip` in the repo root (or creates `project.zip` if there isn't one) with the zip you picked.
- The commit message contains `[skip ci]` so a push trigger doesn't start a second build.
- With no zip selected the button just rebuilds what's already in the repo.
- GitHub's file API limit is ~100 MB; the app stops at 90 MB.

## What it auto-detects
- Default branch.
- A workflow with `workflow_dispatch` (tries build/apk-looking ones first).
- If none exists it commits `.github/workflows/build-apk.yml` to the repo, then uses it.
- The app name and package: read from the built APK itself, so nothing to type.

## Install step
Installed non-system apps with the same name or package as the new build are removed first
(you tap the system "Uninstall" dialog), then the new APK is installed. CI debug builds are
signed with a fresh key every run, so Android refuses to update in place; that's why removal is needed.

## Notes
- Android never allows silent uninstall/install.
- Token is saved in app-private SharedPreferences; use EncryptedSharedPreferences to harden.
- The repo needs a Gradle project (`settings.gradle.kts`) or a project `.zip` in its root.
